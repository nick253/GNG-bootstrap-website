// Mixitup Settings
var containerEl = document.querySelector('#portfolioList');
var mixer = mixitup(containerEl);
